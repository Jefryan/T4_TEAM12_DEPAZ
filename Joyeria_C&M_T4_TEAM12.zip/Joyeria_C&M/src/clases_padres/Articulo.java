package clases_padres;

public class Articulo {
	protected String ID_Articulo;

    public String getID_Articulo() {
        return ID_Articulo;
    }

    public void setID_Articulo(String ID_Articulo) {
        this.ID_Articulo = ID_Articulo;
    }

    public Articulo(String ID_Articulo) {
        this.ID_Articulo = ID_Articulo;
    }

	
}
